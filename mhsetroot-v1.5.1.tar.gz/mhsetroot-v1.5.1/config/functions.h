
#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED





#define DESCRIPTION "wallpaper setter with user options"
#define PACKAGE_STRING "mhrootimg 1.0"
#define PACKAGE_NAME "mhrootimg"
#define PACKAGE_TARNAME "mhrootimg"
#define VERSION "1.0"
#define PACKAGE_BUGREPORT "userxbw@gmail.com"





#endif // FUNCTIONS_H_INCLUDED
